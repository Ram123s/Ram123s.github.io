import { useState } from "react";


function MyForm() {
    // const [name, setName] = useState('');
    // const [age, setAge] = useState('');
    // const [email, setEmail] = useState('');
   const [inputs,setInputs] = useState ({phone:"+91",email:"@gmail.com" } );

    function handelSubmit(e){
        e.preventDefault();
        console.log('form Sumitted')
        // console.log('current state', name,age,email)
        console.log('Current state',inputs)
    }
    function handelChange(e){
      const name =e.target.name
      const value =e.target.value
      setInputs((previousState) => { return {...previousState,[name]: value}})
    }
  
  return (
    <form onSubmit={handelSubmit}>
        <label>Enter your name:
          <input type="text" name="name" onChange={handelChange}   />
    
      </label> <br/>
      <label>Enter your age:
          <input type="text" name="age" onChange={handelChange}  />
    
      </label> <br/>
      <label>Enter your email:
          <input type="text" name="email" onChange={handelChange} value={inputs.email} />
    
      </label>
     
      <label>Enter your phone:
          <input type="text" name="phone" onChange={handelChange} value={inputs.phone}  />
    
      </label> <br/>
      <label>Enter your country:
          <select name="country" onChange={handelChange} value={inputs.country} >o
          <option value="">select</option>
          <option value="India">India</option>
          <option value="Australia">Australia</option>
          <option value="US">US</option>
           </select>
    
      </label><br/>

      <input type="submit" value="submit Form" />
    </form>
   
  )

}
export default MyForm